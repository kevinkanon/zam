<?php

echo "<div class='col-lg-12' style='margin-top:10px;margin-bottom:20px;'><a target='_blank' title='Click Here To Get This' href='http://xpert-idea.com/promotion/promotion.php'><img style='max-width:100%;height:auto;' src='promo_bottom.png' alt='promotional banner'></a></div>";

?>